// NO. 2 
function lookYourEnemy(map) {
    //your code here
 
}

console.log(lookYourEnemy([
    ['x', '', 'x'],
    ['o', '', ''],
    ['', 'x', '']
]));

//there are 3 enemies: 2nd floor 2 enemies, LG floor 1 enemy


console.log(lookYourEnemy([
    ['x', '', 'x'],
    ['', 'o', 'x'],
    ['', 'x', 'x']
]));

//there are 5 enemies: 2nd floor 2 enemies, 1st floor 1 enemy, LG floor 2 enemies
