// NO. 1 
function myPrime(num) {

}

function giveMePrime(level) {
    //your code here

}

console.log(giveMePrime(3));
// [
//   [2, 3, 5],
//   [7, 11, 13],
//   [17, 19, 23]
// ]


console.log(giveMePrime(4));
// [
//   [2, 3, 5, 7],
//   [11, 13, 17, 19],
//   [23, 29, 31, 37,
//   [41, 43, 47, 53]
// ]
